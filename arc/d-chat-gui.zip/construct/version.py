version = (2, 5, 0)
version_string = "2.5.0"
release_date = "2013.01.19"
