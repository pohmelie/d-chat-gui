"""Basic algorithms.

Many of these are from other authors (as noted in the code).
"""
from GenericCallback import *
from IDGen import *
from MatchList import *
from MultiDict import *
from MultiListIter import *
from OrderedDict import *
from RandomWalk import *
