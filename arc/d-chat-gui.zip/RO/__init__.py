"""Various utilities written, adapted or borrowed by Russell Owen

See ../README.txt and ../docs of source code
for information and license
"""
from Version import __version__