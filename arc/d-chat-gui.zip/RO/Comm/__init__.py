"""Event-based communication and timing

Generic contains some common classes that can work with either the Tk event loop or Twisted Framework.
"""
