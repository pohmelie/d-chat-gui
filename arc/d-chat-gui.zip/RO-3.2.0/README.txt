RO is a package of python utilities with an emphasis on cross-platform support
(MacOS X, Windows and unix), Astronomy, Tkinter GUI extensions and
Tkinter-compatible networking.

The docs directory contains installation instructions, an overview, 
version history and the license.

